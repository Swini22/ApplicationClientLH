package nuketown.model;

public class GameLobby {
}
