package nuketown.model;

public class Block {

}
