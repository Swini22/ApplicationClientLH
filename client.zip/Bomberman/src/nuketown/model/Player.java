package nuketown.model;

public class Player {

}
