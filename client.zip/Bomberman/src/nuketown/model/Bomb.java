package nuketown.model;

public class Bomb {
}
