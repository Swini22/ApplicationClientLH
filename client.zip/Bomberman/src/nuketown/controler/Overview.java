package nuketown.controler;

import nuketown.view.PlayGroundView;

public class Overview {
    public static void main(String[]args){
		new PlayGroundView();
    }
}
