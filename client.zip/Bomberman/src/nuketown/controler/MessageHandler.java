package nuketown.controler;

import network.Message;
import network.client.ClientApplicationInterface;

public class MessageHandler implements ClientApplicationInterface  {

	@Override
	public void handleMessage(Message message) {
		// TODO Auto-generated method stub
		
	}
}
