package nuketown.controler;

public abstract class Command {

	public abstract void doCommand();
}
