package network.client.nuketown.model;

public class GameLobby {
}
